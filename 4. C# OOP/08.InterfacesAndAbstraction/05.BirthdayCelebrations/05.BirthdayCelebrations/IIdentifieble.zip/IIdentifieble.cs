﻿namespace BirthdayCelebrations
{
    interface IIdentifieble
    {
        string Id { get; }
    }
}
