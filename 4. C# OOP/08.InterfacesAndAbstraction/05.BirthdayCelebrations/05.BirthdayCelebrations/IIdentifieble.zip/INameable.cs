﻿namespace BirthdayCelebrations
{
    interface INameable
    {
        string Name { get;  }
    }
}
