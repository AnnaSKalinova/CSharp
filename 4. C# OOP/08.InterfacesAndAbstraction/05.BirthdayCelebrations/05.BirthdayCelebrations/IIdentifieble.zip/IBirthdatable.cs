﻿using System;

namespace BirthdayCelebrations
{
    interface IBirthdatable
    {
        DateTime Birthdate { get; }
    }
}
