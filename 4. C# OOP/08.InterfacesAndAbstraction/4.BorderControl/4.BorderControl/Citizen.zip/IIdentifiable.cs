﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    interface IIdentifiable
    {
        string Id { get; }
    }
}
