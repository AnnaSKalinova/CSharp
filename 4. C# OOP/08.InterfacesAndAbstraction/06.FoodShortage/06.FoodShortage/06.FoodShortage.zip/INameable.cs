﻿namespace FoodShortage
{
    interface INameable
    {
        string Name { get;  }
    }
}
