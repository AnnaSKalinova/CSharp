﻿namespace FoodShortage
{
    interface IIdentifieble
    {
        string Id { get; }
    }
}
