﻿namespace FoodShortage
{
    interface IAgeble
    {
        int Age { get; }
    }
}
