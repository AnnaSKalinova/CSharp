﻿using System;

namespace FoodShortage
{
    interface IBirthdatable
    {
        DateTime Birthdate { get; }
    }
}
