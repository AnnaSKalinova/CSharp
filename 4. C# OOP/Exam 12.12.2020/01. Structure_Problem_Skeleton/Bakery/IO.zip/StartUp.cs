﻿namespace Bakery
{
    using Bakery.Core;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}
