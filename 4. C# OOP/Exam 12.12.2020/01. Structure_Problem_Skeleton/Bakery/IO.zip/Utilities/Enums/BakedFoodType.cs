﻿namespace Bakery.Utilities.Enums
{
    public enum BakedFoodType
    {
        Bread = 1,
        Cake = 2,
    }
}
