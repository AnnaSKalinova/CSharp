﻿namespace BookShop
{
    using System;
    using Data;
    using Initializer;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);

            var command = Console.ReadLine().ToLower();

            var books = GetBooksByAgeRestriction(db, command);

            Console.WriteLine(books);
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            StringBuilder sb = new StringBuilder();

            var result = context
                .Books
                .ToList()
                .Where(b => b.AgeRestriction.ToString().Equals(command, StringComparison.OrdinalIgnoreCase))
                .Select(b => new
                    {
                        Title = b.Title
                    })
                .OrderBy(b => b.Title)
                .ToList();

            foreach (var book in result)
            {
                sb.AppendLine(book.Title);
            }

            return sb.ToString().TrimEnd();
        }
    }
}
