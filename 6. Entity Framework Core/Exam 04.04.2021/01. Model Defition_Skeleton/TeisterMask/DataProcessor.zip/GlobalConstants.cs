﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask
{
    public class GlobalConstants
    {
        // Employee
        public const string UsernameValidation = @"[A-z0-9]+";
        public const string PhoneValidation = @"[0-9]{3}-[0-9]{3}-[0-9]{4}";
    }
}
