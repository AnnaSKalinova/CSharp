﻿namespace TeisterMask.DataProcessor
{
    using System;
    using System.Collections.Generic;

    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Serialization;
    using Data;
    using Newtonsoft.Json;
    using TeisterMask.Data.Models;
    using TeisterMask.DataProcessor.ImportDto;
    using ValidationContext = System.ComponentModel.DataAnnotations.ValidationContext;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid data!";

        private const string SuccessfullyImportedProject
            = "Successfully imported project - {0} with {1} tasks.";

        private const string SuccessfullyImportedEmployee
            = "Successfully imported employee - {0} with {1} tasks.";

        public static string ImportProjects(TeisterMaskContext context, string xmlString)
        {
            StringBuilder output = new StringBuilder();
            var xmlSerializer = new XmlSerializer(typeof(ProjectImportModel[]), new XmlRootAttribute("Projects"));

            StringReader stringReader = new StringReader(xmlString);

            ProjectImportModel[] projectDtos = (ProjectImportModel[])xmlSerializer.Deserialize(stringReader);

            foreach (var xmlProject in projectDtos)
            {
                var taskOpenDate = xmlProject.Tasks.Select(t => t.OpenDate);
                var projectOpenDate = xmlProject.OpenDate;

                if (!IsValid(xmlProject))
                {
                    output.AppendLine(ErrorMessage);
                    continue;
                }

                DateTime openDate;
                bool isOpenDateValid = DateTime.TryParseExact(xmlProject.OpenDate, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out openDate);

                DateTime dueDate;
                bool isDueDateValid = DateTime.TryParseExact(xmlProject.DueDate, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out dueDate);

                var project = new Project
                {
                    Name = xmlProject.Name,
                    DueDate = dueDate,
                    OpenDate = openDate,
                    Tasks = xmlProject.Tasks.Select(t => new Task
                    {
                        Name = t.Name,
                        OpenDate = openDate,
                        DueDate = dueDate,
                        ExecutionType = t.ExecutionType.Value,
                        LabelType = t.LabelType.Value
                    })
                    .ToArray(),
                };

                context.Projects.Add(project);
                context.SaveChanges();
                output.AppendLine($"Successfully imported employee - {project.Name} with {project.Tasks.Count()} tasks.");
            }

            return null;
        }

        public static string ImportEmployees(TeisterMaskContext context, string jsonString)
        {
            StringBuilder output = new StringBuilder();
            var data = JsonConvert.DeserializeObject<IEnumerable<EmployeesImportModel>>(jsonString);


            foreach (var jsonEmployee in data)
            {
                if (!IsValid(jsonEmployee))
                {
                    output.AppendLine(ErrorMessage);
                    continue;
                }

                var employee = new Employee
                {
                    Username = jsonEmployee.Username,
                    Email = jsonEmployee.Email,
                    Phone = jsonEmployee.Phone,
                    EmployeesTasks = jsonEmployee.Tasks.Select(t => new EmployeeTask
                    {
                        TaskId = t.Id
                    })
                    .ToArray()
                };

                context.Employees.Add(employee);
                context.SaveChanges();
                output.AppendLine($"Successfully imported employee - {employee.Username} with {employee.EmployeesTasks.Count()} tasks.");
            }

            return output.ToString().TrimEnd();
        }

        private static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }
    }
}