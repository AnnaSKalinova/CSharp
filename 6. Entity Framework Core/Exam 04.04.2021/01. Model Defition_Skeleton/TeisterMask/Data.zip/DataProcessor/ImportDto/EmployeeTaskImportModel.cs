﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask.DataProcessor.ImportDto
{
    public class EmployeeTaskImportModel
    {
        public int Id { get; set; }
    }
}
