﻿namespace MusicHub
{
    using System;
    using System.Text;
    using Data;
    using System.Linq;
    using Initializer;
    using System.Globalization;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            MusicHubDbContext context = 
                new MusicHubDbContext();

            DbInitializer.ResetDatabase(context);

            // Problem 2

            var albums = ExportAlbumsInfo(context, 9);
            Console.WriteLine(albums);
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            StringBuilder sb = new StringBuilder();

            var albums = context
                    .Albums
                    .ToList()
                    .Where(a => a.ProducerId == producerId)
                    .Select(a => new
                    {
                        Name = a.Name,
                        ReleaseDate = a.ReleaseDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture),
                        ProducerName = a.Producer.Name,
                        AlbumSongs = a.Songs.Select(s => new
                        {
                            Name = s.Name,
                            Price = s.Price,
                            SongWriter = s.Writer.Name
                        })
                            .OrderByDescending(s => s.Name)
                            .ThenBy(s => s.SongWriter)
                            .ToList(),
                        AlbumPrice = a.Price
                    })
                    .OrderByDescending(a => a.AlbumPrice)
                    .ToList();

            foreach (var album in albums)
            {
                sb.AppendLine($"-AlbumName: {album.Name}");
                sb.AppendLine($"-ReleaseDate: {album.ReleaseDate}");
                sb.AppendLine($"-ProducerName: {album.ProducerName}");
                sb.AppendLine("-Songs:");
                var counter = 1;

                foreach (var song in album.AlbumSongs)
                {
                    sb.AppendLine($"---#{counter}");
                    sb.AppendLine($"---SongName: {song.Name}");
                    sb.AppendLine($"---Price: {song.Price:F2}");
                    sb.AppendLine($"---Writer: {song.SongWriter}");
                    counter++;
                }

                sb.AppendLine($"-AlbumPrice: {album.AlbumPrice:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            throw new NotImplementedException();
        }
    }
}
