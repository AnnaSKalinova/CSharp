﻿namespace VaporStore.DataProcessor
{
	using System;
    using System.Linq;
    using Data;
    using Newtonsoft.Json;

    public static class Serializer
	{
		public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
		{
			var genres = context.Genres
				.ToArray()
				.Where(gr => genreNames.Contains(gr.Name))
				.Select(gr => new
				{
					Id = gr.Id,
					Genre = gr.Name,
					Games = gr.Games
							.Where(gm => gm.Purchases.Any())
							.Select(gm => new
							{
								Id = gm.Id,
								Title = gm.Name,
								Developer = gm.Developer.Name,
								Tags = String.Join(", ", gm.GameTags
										.Select(t => t.Tag.Name)
										.ToArray()),
								Players = gm.Purchases.Count
							})
							.OrderByDescending(gm => gm.Players)
							.ThenBy(gm => gm.Id)
							.ToArray(),
					TotalPlayers = gr.Games.Sum(gm => gm.Purchases.Count)
				})
				.OrderByDescending(gr => gr.TotalPlayers)
				.ThenBy(gr => gr.Id)
				.ToArray();

			var json = JsonConvert.SerializeObject(genres, Formatting.Indented);

			return json;
		}

		public static string ExportUserPurchasesByType(VaporStoreDbContext context, string storeType)
		{
			return null;
		}
	}
}