﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftJail
{
    public class GlobalConstants
    {
        // Prisoner
        public const string NickNameValidation = @"The [A-Z][a-z]+";

        // Address
        public const string AddressValidation = @"[0-9A-z ]+ str.";
    }
}
