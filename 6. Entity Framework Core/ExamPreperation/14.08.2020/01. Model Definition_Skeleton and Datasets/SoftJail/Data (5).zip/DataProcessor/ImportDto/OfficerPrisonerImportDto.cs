﻿using System.Xml.Serialization;

namespace SoftJail.DataProcessor.ImportDto
{
    [XmlType("Prisoner")]
    public class OfficerPrisonerImportDto
    {
        [XmlAttribute("id")]
        public int Id { get; set; }
    }
}