﻿namespace Cinema.DataProcessor
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.Text;
    using Cinema.Data.Models;
    using Cinema.DataProcessor.ImportDto;
    using Data;
    using Newtonsoft.Json;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid data!";

        private const string SuccessfulImportMovie 
            = "Successfully imported {0} with genre {1} and rating {2}!";

        private const string SuccessfulImportProjection 
            = "Successfully imported projection {0} on {1}!";

        private const string SuccessfulImportCustomerTicket 
            = "Successfully imported customer {0} {1} with bought tickets: {2}!";

        public static string ImportMovies(CinemaContext context, string jsonString)
        {
            StringBuilder sb = new StringBuilder();

            List<string> moviesAdded = new List<string>();

            var jsonData = JsonConvert.DeserializeObject<MoviesImportDto[]>(jsonString);

            foreach (var jsonMovie in jsonData)
            {
                if (!IsValid(jsonMovie) || moviesAdded.Contains(jsonMovie.Title))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                //TimeSpan duration;
                //bool isDurationValid = TimeSpan.TryParseExact(jsonMovie.Duration, "hh:mm:ss", CultureInfo.InvariantCulture, TimeSpanStyles.None, out duration);

                //if (!isDurationValid)
                //{
                //    sb.AppendLine(ErrorMessage);
                //    continue;
                //}

                var movie = new Movie
                {
                    Title = jsonMovie.Title,
                    Genre = jsonMovie.Genre,
                    Duration = jsonMovie.Duration,
                    Rating = jsonMovie.Rating,
                    Director = jsonMovie.Director
                };

                moviesAdded.Add(movie.Title);
                context.Movies.Add(movie);
                context.SaveChanges();
                sb.AppendLine($"Successfully imported {jsonMovie.Title} with genre {jsonMovie.Genre} and rating {jsonMovie.Rating:F2}!");
            }

            return sb.ToString().TrimEnd();
        }

        public static string ImportProjections(CinemaContext context, string xmlString)
        {
            throw new NotImplementedException();
        }

        public static string ImportCustomerTickets(CinemaContext context, string xmlString)
        {
            throw new NotImplementedException();
        }

        private static bool IsValid(object obj)
        {
            var validationContext = new System.ComponentModel.DataAnnotations.ValidationContext(obj);
            var validationResult = new List<ValidationResult>();

            bool isValid = Validator.TryValidateObject(obj, validationContext, validationResult, true);
            return isValid;
        }
    }
}