﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DefiningClasses
{
    public class Family
    {
        private List<Person> family;

        public Family()
        {
            this.family = new List<Person>();
        }

        public void AddMember(Person member)
        {
            this.family.Add(member);
        }

        public Person GetOldestMember()
        {
            Person oldestPerson = this.family
                .OrderByDescending(p => p.Age)
                .FirstOrDefault();

            return oldestPerson;
        }

        public List<Person> GetPeopleInAgeRange()
        {
            List<Person> peopleInAgeRange = this.family
                .Where(p => p.Age > 30)
                .OrderBy(p => p.Name)
                .ToList();

            return peopleInAgeRange;
        }
    }
}
